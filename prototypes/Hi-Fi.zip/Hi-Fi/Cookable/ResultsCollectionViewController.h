//
//  ResultsCollectionViewController.h
//  Cookable
//
//  Created by Alex Wolff on 4/6/14.
//  Copyright (c) 2014 Alex Wolff. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultsCollectionViewController : UICollectionViewController

@end
